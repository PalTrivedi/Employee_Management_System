package Pack;

import java.util.*;
import java.sql.*;
import java.io.*;
import java.sql.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        Connection con = App.Check();
        System.out.print("\033[H\033[2J");
        System.out.flush();
        System.out.println(
                "\n\t\t * * * * * W E L C O M E  T O  E M P L O Y E E  M A N A G E M E N T   S Y S T E M * * * * *");
        System.out.println();
        while (true) {
            System.out.print(
                    "\t\t\t\t\t\t1.Admin login\n\t\t\t\t\t\t2.Employee login\n\t\t\t\t\t\t3.Exit\n\t\t\t\t\t\tEnter your choice : ");
            int loginChoice = sc.nextInt();
            switch (loginChoice) {
                case 1:
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    FileCreator fc = new FileCreator();
                    fc.createFiles("AdminData.txt",
                            "rajurastogi@mail.com\nrr456\nfarhanqureshi@mail.com\nfq789\nbaburao@mail.comr\nbr097\nshyampatel@mail.com\nsp646\nmunnikhan@mail.com\nmk149\naadityaroy@mail.com\nar474\ngeetkapoor@mail.com\ngk205");
                    System.out.println();
                    System.out.println();
                    for (int i = 0; i <= 3; i++) {
                        System.out.print("\t\t\t\tEnter admin Id : ");
                        String adminId = sc.next();
                        System.out.print("\t\t\t\tEnter password : ");
                        String adminPass = sc.next();
                        if (i == 2) {
                            System.out.println("You have last attempt left for correct credentials");
                            System.out.println("After one more failed attempt you'll be redirected to home page");
                        }
                        if (!loginAdmin(adminId, adminPass)) {
                            System.out.println("Invalid Credentials");
                        } else {
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            Admin a = new Admin(adminId);
                            a.adminChoice();
                            i = 3;
                        }
                    }
                    break;
                case 2:
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    for (int i = 0; i <= 3; i++) {
                        System.out.print("\t\t\t\tEnter employee ID : ");
                        int empId = sc.nextInt();
                        System.out.print("\t\t\t\tEnter empoyee DOB(YYYY-MM-DD) : ");
                        String date = sc.next();
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                        Date dob = Date.valueOf(LocalDate.parse(date, formatter));
                        if (i == 2) {
                            System.out.println();
                            System.out.println("\t\t\t\t! !  W A R N I N G  ! !");
                            System.out.println();
                            System.out.println("You have last attempt left for correct credentials");
                            System.out.println("After one more failed attempt you'll be redirected to home page");
                            System.out.println();
                        }
                        if (!loginEmployee(empId, dob)) {
                            System.out.println("\t\t\t\tInvalid Credentials");
                        } else {
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            Employee e = new Employee(empId, con);
                            e.employeeChoice();
                            i = 3;
                        }
                    }
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("\t\t\t\tInvalid input");

            }
        }
    }

    static boolean loginEmployee(int id, Date dob) throws Exception {
        Connection con = App.Check();
        String sql = "{? = call loginEmployee(?,?)}";
        CallableStatement cst = con.prepareCall(sql);
        cst.registerOutParameter(1, Types.INTEGER);
        cst.setDate(2, dob);
        cst.setInt(3, id);
        cst.execute();
        boolean result = cst.getBoolean(1);
        return result;
    }

    static boolean loginAdmin(String id, String pass) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("AdminData.txt"));
        String read;
        while ((read = br.readLine()) != null) {
            if (read.equals(id)) {
                read = br.readLine();
                if (read.equals(pass)) {
                    br.close();
                    return true;
                }
            }
        }
        br.close();
        return false;
    }
}
